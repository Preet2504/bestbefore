package com.example.tokmanniexpirysystem2.utilities;

import android.app.Application;
import android.content.Context;

import com.example.tokmanniexpirysystem2.R;

public enum Role {
    USER, ADMIN, DEFAULT
}
