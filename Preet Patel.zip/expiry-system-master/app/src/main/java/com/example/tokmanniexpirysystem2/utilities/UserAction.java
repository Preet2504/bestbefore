package com.example.tokmanniexpirysystem2.utilities;

public enum UserAction {
    CREAT, EDIT, SIGN_IN, SIGN_OUT, DELETE, UPDATE
}
