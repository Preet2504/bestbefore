package com.example.tokmanniexpirysystem2.utilities;

import android.content.Context;
import android.os.AsyncTask;

import com.example.tokmanniexpirysystem2.database.DatabaseClient;
import com.example.tokmanniexpirysystem2.entities.Product;
import com.example.tokmanniexpirysystem2.entities.User;
import com.example.tokmanniexpirysystem2.listadapters.ProductRecyclerviewAdapter;

import java.util.Collections;
import java.util.List;

public class Authintication {


    public static String userName;
    public static String role;
    public static User user;




}
