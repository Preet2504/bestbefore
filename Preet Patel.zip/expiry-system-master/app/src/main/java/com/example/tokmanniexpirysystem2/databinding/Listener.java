package com.example.tokmanniexpirysystem2.databinding;

import android.view.View;

public interface Listener {

    void onClick(View view);

}